class SimulationError(Exception):
    pass
