PRÉCISION
Class  
    -AttributeDeclaration représente une ligne de déclaration d'attribut. 
    -DeclareAttribut se trouve à l'intérieur de cette ligne. Il représente la déclaration d'une variable (Ex int a)
    -MethodSignature est représenté par un ou plusieurs Identifier où le premier représente le nom de la méthode et les autres
     les paramètres
    
If
    -Pour ce qui est des conditions des If et ElseIf, ils sont affichés respectivement avant IfBody et ElseIfBody 
     (au même niveau dans l'arbre)

